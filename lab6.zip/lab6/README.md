# Lab 6: SQL and PHP exercises

In this lab, you should complete exercises given in `lab6a.pdf` and `lab6b.pdf`.

You will practice your SQL skills and also implement a web page which dynamically loads and updates everything in database.

- For `lab6a`, write all you SQL statements in a `lab6a.sql` file.
- For `lab6b`, create a separate folder within this directory, and write all necessary PHP there.


### Student Details:

- **Student ID**: U1610120
- **Student Name**: Anora Kosimova
- **Section Number**: 002 section number
